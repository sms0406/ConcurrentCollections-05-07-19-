package pack1;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class ConcurrentDemo3 extends Thread{
	static CopyOnWriteArrayList list =  new CopyOnWriteArrayList(); 
	public void run() 
	{ 
		try { 
			Thread.sleep(2000); 
		} 
		catch (InterruptedException e) { 
			System.out.println("Child Thread"
					+ " going to add element"); 
		} 

		System.out.println("child thread going to add");
		list.add("D"); 
	} 

	public static void main(String[] args) 
			throws InterruptedException 
	{ 
		list.add("A"); 
		list.add("B"); 
		list.add("c"); 

		 
		ConcurrentDemo3 thread = new ConcurrentDemo3(); 
		thread.start(); 


		Iterator itr = list.iterator(); 
		while (itr.hasNext()) { 
			String s = (String)itr.next(); 
			System.out.println(s); 
			Thread.sleep(6000); 
		} 
		System.out.println(list); 
	}
}
