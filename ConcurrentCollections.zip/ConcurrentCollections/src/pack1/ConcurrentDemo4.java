package pack1;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

class BlockingQueueProducer implements Runnable {

	protected BlockingQueue<String> blockingQueue;

	public BlockingQueueProducer(BlockingQueue<String> queue) {
		this.blockingQueue = queue;
	}

	public void run() {
		try {
			Thread.sleep(500);
			
			blockingQueue.put("Apple");
			System.out.println("producer put apple");
			//Thread.sleep(1000);
		
			blockingQueue.put("Orange");
			System.out.println("producer put orange");
			//Thread.sleep(2000);
			
			//blockingQueue.put("Mango");
			//System.out.println("producer put mango");
			boolean result=blockingQueue.offer("Mango",5000,TimeUnit.MILLISECONDS);
			System.out.println("producer put mango "+result);
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}


class BlockingQueueConsumer implements Runnable {
	protected BlockingQueue<String> blockingQueue;

	public BlockingQueueConsumer(BlockingQueue<String> queue) {
		this.blockingQueue = queue;
	}

	public void run() {
		try {
			Thread.sleep(2000);
			System.out.println("consuming "+blockingQueue.take());
			Thread.sleep(2000);
			System.out.println("consuming "+blockingQueue.take());
			Thread.sleep(2000);
			System.out.println("consuming "+blockingQueue.take());
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

public class ConcurrentDemo4 {

	
	public static void main(String[] args) throws Exception {

		BlockingQueue<String> blockingQueue = new ArrayBlockingQueue<String>(2);

		BlockingQueueProducer queueProducer = new BlockingQueueProducer(blockingQueue);
		BlockingQueueConsumer queueConsumer = new BlockingQueueConsumer(blockingQueue);

		new Thread(queueProducer).start();
		//new Thread(queueConsumer).start();
	}
}
