package pack1;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;

public class ConcurrentDemo2 extends Thread{
	static ArrayList list = new ArrayList(); 
    public void run() 
    { 
        
            try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			
				e.printStackTrace();
			} 
       
         System.out.println("child thread going to add");
        list.add("D"); 
    } 
  
    public static void main(String[] args) 
        throws InterruptedException 
    { 
        list.add("A"); 
        list.add("B"); 
        list.add("c"); 
  
      
        ConcurrentDemo2 t = new ConcurrentDemo2(); 
        t.start(); 
  
         
        Iterator itr = list.iterator(); 
        while (itr.hasNext()) {                	
            String s = (String)itr.next(); 
            System.out.println(s); 
            Thread.sleep(6000); 
        } 
        System.out.println(list); 
    } 
}
