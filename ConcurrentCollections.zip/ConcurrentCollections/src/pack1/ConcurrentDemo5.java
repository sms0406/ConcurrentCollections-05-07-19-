package pack1;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class RunnableMap implements Runnable {
	Map<String, Integer> map;

	public RunnableMap(Map<String, Integer> map) {
		this.map = map;
		new Thread(this).start();
	}

	public void run() {
		
		map.put(Thread.currentThread().getName(), 1);
		try {
			System.out.println(Thread.currentThread().getName() + " sleeping");
			Thread.sleep(100);
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
public class ConcurrentDemo5 {

	
	public static void main(String[] args) {
		//Map<String, Integer> hashMap = new HashMap<>();
		Map<String, Integer> cMap = new ConcurrentHashMap<>();
		RunnableMap task1 = new RunnableMap(cMap);
		RunnableMap task2 = new RunnableMap(cMap);
		RunnableMap task3 = new RunnableMap(cMap);
		RunnableMap task4 = new RunnableMap(cMap);
		/*System.out.println("map size "+hashMap.size());
		for (Map.Entry<String, Integer> e : hashMap.entrySet()) {
			System.out.println(e.getKey() + "=" + e.getValue());
		}*/
		System.out.println(" map size "+cMap.size());
		for (Map.Entry<String, Integer> e : cMap.entrySet()) {
			System.out.println(e.getKey() + "=" + e.getValue());
		}

	}
}
