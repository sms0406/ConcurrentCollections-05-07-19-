package pack1;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class Foo {
	private Map<String, Object> theMap = new ConcurrentHashMap<>();
	
	public  Object getOrCreate(String key) {
		
		/*Object value = theMap.get(key);
		System.out.println(Thread.currentThread().getName()+ " value " + value);
		if (value == null) {
			value = new Object();
			theMap.put(key, value);
		}
		return value;*/
		return theMap.computeIfAbsent(key, k -> new Object());
    }
}
class MyThread extends Thread{
	Foo foo;
	MyThread(Foo foo){
		this.foo=foo;
	}
	public void run() {
		Object obj=foo.getOrCreate("hi");
		
		System.out.println("value returned by "+Thread.currentThread().getName()+" "+obj);
	}
}
public class ConcurrentDemo6 {
	public static void main(String[] args) {
		Foo foo = new Foo();
		MyThread thread1 = new MyThread(foo);
	
		thread1.start();
		MyThread thread2 = new MyThread(foo);
		thread2.start();
		System.out.println("main ends");
				
	}

}
