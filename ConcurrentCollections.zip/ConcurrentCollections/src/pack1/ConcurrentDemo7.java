package pack1;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentDemo7 {
public static void main(String[] args) {
	ConcurrentHashMap<String,String>map = new ConcurrentHashMap<>();
	map.put("A", "one");
	map.put("B", "Two");
	map.put("C", "Three");
	map.put("D", "four");
	map.forEach(2,(key,value)-> System.out.printf("    k: %s, v: %s%n", key, value));
	//String result=map.search(2, (key,value)->value.startsWith("T")?key:null);
	//System.out.println(result);
}
}
